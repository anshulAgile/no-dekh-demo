import React from 'react'

const City = () => {
    return (
        <div>City</div>
    )
}

export default City